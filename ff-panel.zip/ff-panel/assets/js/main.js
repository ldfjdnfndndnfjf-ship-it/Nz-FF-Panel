/**
 * ============================================
 *  FF Pro Panel — Main Interaction Script
 *  Handles modals, auth, navigation, UI
 * ============================================
 */

class FFPanel {
    constructor() {
        this.currentUser = null;
        this.isAuthenticated = false;

        this.initPreloader();
        this.initNavigation();
        this.initModals();
        this.initAuthForms();
        this.initScrollEffects();
        this.checkAuthState();
    }

    /**
     * Preloader animation
     */
    initPreloader() {
        window.addEventListener('load', () => {
            const preloader = document.getElementById('preloader');
            if (preloader) {
                setTimeout(() => {
                    preloader.classList.add('hidden');
                }, 800);
            }
        });
    }

    /**
     * Navigation: hamburger menu, active links, smooth scroll
     */
    initNavigation() {
        const hamburger = document.getElementById('hamburger');
        const navLinks = document.getElementById('navLinks');

        if (hamburger && navLinks) {
            hamburger.addEventListener('click', () => {
                navLinks.classList.toggle('active');
                hamburger.classList.toggle('active');
            });

            // Close nav when clicking a link
            navLinks.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    navLinks.classList.remove('active');
                    hamburger.classList.remove('active');
                });
            });
        }

        // Active link tracking on scroll
        const sections = document.querySelectorAll('section[id]');
        window.addEventListener('scroll', () => {
            let current = '';
            sections.forEach(section => {
                const sectionTop = section.offsetTop - 150;
                if (window.scrollY >= sectionTop) {
                    current = section.getAttribute('id');
                }
            });

            document.querySelectorAll('.nav-links a').forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${current}`) {
                    link.classList.add('active');
                }
            });
        });
    }

    /**
     * Modal system
     */
    initModals() {
        this.loginModal = document.getElementById('loginModal');
        this.registerModal = document.getElementById('registerModal');

        const loginBtn = document.getElementById('loginBtn');
        const registerBtn = document.getElementById('registerBtn');
        const switchToRegister = document.getElementById('switchToRegister');
        const switchToLogin = document.getElementById('switchToLogin');
        const closeButtons = document.querySelectorAll('.close-modal');

        // Open modals
        if (loginBtn) {
            loginBtn.addEventListener('click', () => this.openModal('login'));
        }
        if (registerBtn) {
            registerBtn.addEventListener('click', () => this.openModal('register'));
        }

        // Switch between modals
        if (switchToRegister) {
            switchToRegister.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeModal('login');
                this.openModal('register');
            });
        }
        if (switchToLogin) {
            switchToLogin.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeModal('register');
                this.openModal('login');
            });
        }

        // Close buttons
        closeButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                this.closeModal('login');
                this.closeModal('register');
            });
        });

        // Close on outside click
        window.addEventListener('click', (e) => {
            if (e.target === this.loginModal) {
                this.closeModal('login');
            }
            if (e.target === this.registerModal) {
                this.closeModal('register');
            }
        });

        // Close on Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeModal('login');
                this.closeModal('register');
            }
        });
    }

    openModal(type) {
        const modal = type === 'login' ? this.loginModal : this.registerModal;
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    closeModal(type) {
        const modal = type === 'login' ? this.loginModal : this.registerModal;
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    /**
     * Authentication forms
     */
    initAuthForms() {
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');

        if (loginForm) {
            loginForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const username = document.getElementById('loginUsername').value.trim();
                const password = document.getElementById('loginPassword').value;

                if (!username || !password) {
                    this.showToast('Please fill all fields', 'error');
                    return;
                }

                try {
                    const response = await fetch('server/login.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ username, password })
                    });

                    const data = await response.json();

                    if (data.success) {
                        this.currentUser = data.user;
                        this.isAuthenticated = true;
                        localStorage.setItem('ff_panel_user', JSON.stringify(data.user));
                        this.closeModal('login');
                        this.showToast(`Welcome back, ${data.user.username}!`, 'success');
                        this.updateUIForAuth();
                        loginForm.reset();
                    } else {
                        this.showToast(data.message || 'Login failed', 'error');
                    }
                } catch (error) {
                    console.error('Login error:', error);
                    this.showToast('Network error. Please try again.', 'error');
                }
            });
        }

        if (registerForm) {
            registerForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const username = document.getElementById('regUsername').value.trim();
                const email = document.getElementById('regEmail').value.trim();
                const password = document.getElementById('regPassword').value;
                const referral = document.getElementById('regReferral').value.trim();

                if (!username || !email || !password) {
                    this.showToast('Please fill all required fields', 'error');
                    return;
                }

                if (password.length < 6) {
                    this.showToast('Password must be at least 6 characters', 'error');
                    return;
                }

                try {
                    const response = await fetch('server/register.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ username, email, password, referral })
                    });

                    const data = await response.json();

                    if (data.success) {
                        this.showToast('Registration successful! Please login.', 'success');
                        this.closeModal('register');
                        this.openModal('login');
                        registerForm.reset();
                    } else {
                        this.showToast(data.message || 'Registration failed', 'error');
                    }
                } catch (error) {
                    console.error('Registration error:', error);
                    this.showToast('Network error. Please try again.', 'error');
                }
            });
        }
    }

    /**
     * Update UI when user is authenticated
     */
    updateUIForAuth() {
        const loginBtn = document.getElementById('loginBtn');
        const registerBtn = document.getElementById('registerBtn');

        if (loginBtn) {
            loginBtn.textContent = this.currentUser?.username || 'Profile';
            loginBtn.onclick = () => {
                // Could show profile dropdown
                this.showToast(`Logged in as ${this.currentUser?.username}`, 'info');
            };
        }
        if (registerBtn) {
            registerBtn.textContent = 'Logout';
            registerBtn.className = 'btn btn-danger';
            registerBtn.onclick = () => this.logout();
        }
    }

    logout() {
        this.currentUser = null;
        this.isAuthenticated = false;
        localStorage.removeItem('ff_panel_user');

        const loginBtn = document.getElementById('loginBtn');
        const registerBtn = document.getElementById('registerBtn');

        if (loginBtn) {
            loginBtn.textContent = 'Login';
            loginBtn.onclick = () => this.openModal('login');
        }
        if (registerBtn) {
            registerBtn.textContent = 'Register';
            registerBtn.className = 'btn btn-primary';
            registerBtn.onclick = () => this.openModal('register');
        }

        this.showToast('Logged out successfully', 'info');
    }

    checkAuthState() {
        const savedUser = localStorage.getItem('ff_panel_user');
        if (savedUser) {
            try {
                this.currentUser = JSON.parse(savedUser);
                this.isAuthenticated = true;
                this.updateUIForAuth();
            } catch {
                localStorage.removeItem('ff_panel_user');
            }
        }
    }

    /**
     * Scroll effects: reveal animations on scroll
     */
    initScrollEffects() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        // Observe all feature cards and sections
        document.querySelectorAll('.feature-card, .section-title, .vc-card').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
            observer.observe(el);
        });

        // Also observe when they become revealed
        document.addEventListener('revealed', (e) => {
            // Custom event handling
        });
    }

    /**
     * Toast notification system
     */
    showToast(message, type = 'info') {
        // Remove existing toasts
        const existingToasts = document.querySelectorAll('.toast');
        existingToasts.forEach(t => t.remove());

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;

        const icons = {
            success: '✓',
            error: '✕',
            info: 'ℹ'
        };

        toast.innerHTML = `<span class="toast-icon">${icons[type] || 'ℹ'}</span> ${message}`;

        Object.assign(toast.style, {
            position: 'fixed',
            top: '90px',
            right: '20px',
            padding: '14px 24px',
            borderRadius: '10px',
            color: '#fff',
            fontSize: '0.95rem',
            fontWeight: '500',
            zIndex: '9999',
            opacity: '0',
            transform: 'translateX(50px)',
            transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            maxWidth: '400px'
        });

        const colors = {
            success: 'linear-gradient(135deg, #00c853, #009624)',
            error: 'linear-gradient(135deg, #ff1744, #d50000)',
            info: 'linear-gradient(135deg, #2979ff, #0d47a1)'
        };

        toast.style.background = colors[type] || colors.info;

        document.body.appendChild(toast);

        // Animate in
        requestAnimationFrame(() => {
            toast.style.opacity = '1';
            toast.style.transform = 'translateX(0)';
        });

        // Auto remove
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(50px)';
            setTimeout(() => toast.remove(), 400);
        }, 3500);
    }
}

// Global utility for smooth scrolling
window.scrollToSection = function(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
};

// Initialize panel when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.ffPanel = new FFPanel();
});

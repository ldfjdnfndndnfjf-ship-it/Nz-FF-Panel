/**
 * ============================================
 *  FF Pro Panel — Voice Changer Engine
 *  Professional-grade real-time voice modulation
 *  Powered by Web Audio API + Tone.js
 * ============================================
 */

class VoiceChangerEngine {
    constructor() {
        // Audio context and nodes
        this.audioContext = null;
        this.mediaStream = null;
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.audioBlob = null;
        this.audioUrl = null;
        this.isRecording = false;

        // DOM references
        this.canvas = document.getElementById('audioCanvas');
        this.canvasCtx = this.canvas?.getContext('2d');
        this.analyserNode = null;
        this.animationId = null;

        // State
        this.currentEffect = 'none';
        this.pitch = 1.0;
        this.speed = 1.0;
        this.reverb = 0;

        // Bind UI events
        this.bindUIEvents();
    }

    /**
     * Initialize audio context (must be called from user gesture)
     */
    async initAudioContext() {
        if (this.audioContext) return;

        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        this.audioContext = new AudioCtx();

        // Create analyser for visualizer
        this.analyserNode = this.audioContext.createAnalyser();
        this.analyserNode.fftSize = 256;
    }

    /**
     * Start recording from microphone
     */
    async startRecording() {
        try {
            await this.initAudioContext();

            // Request mic access
            this.mediaStream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    sampleRate: 44100
                }
            });

            // Connect to analyser for visualization
            const source = this.audioContext.createMediaStreamSource(this.mediaStream);
            source.connect(this.analyserNode);

            // Start visualizer
            this.startVisualizer();

            // Setup MediaRecorder
            this.audioChunks = [];
            const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
                ? 'audio/webm;codecs=opus'
                : 'audio/webm';

            this.mediaRecorder = new MediaRecorder(this.mediaStream, { mimeType });

            this.mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    this.audioChunks.push(event.data);
                }
            };

            this.mediaRecorder.onstop = () => {
                this.processRecording();
                this.stopVisualizer();
                // Stop all tracks
                if (this.mediaStream) {
                    this.mediaStream.getTracks().forEach(track => track.stop());
                }
            };

            this.mediaRecorder.start(100); // collect data every 100ms
            this.isRecording = true;

            return { success: true, message: 'Recording started' };

        } catch (error) {
            console.error('Voice Changer Error:', error);
            return {
                success: false,
                message: error.name === 'NotAllowedError'
                    ? 'Microphone access denied. Please allow microphone permissions.'
                    : `Error: ${error.message}`
            };
        }
    }

    /**
     * Stop recording
     */
    stopRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.isRecording = false;
            return { success: true, message: 'Recording stopped' };
        }
        return { success: false, message: 'No active recording' };
    }

    /**
     * Process the recorded audio with selected effects
     */
    async processRecording() {
        if (this.audioChunks.length === 0) return;

        const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
        this.audioBlob = audioBlob;
        this.audioUrl = URL.createObjectURL(audioBlob);
    }

    /**
     * Play back the processed audio
     */
    async playProcessed() {
        if (!this.audioBlob) return { success: false, message: 'No recording to play' };

        try {
            const arrayBuffer = await this.audioBlob.arrayBuffer();
            const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);

            const processedBuffer = await this.applyEffects(audioBuffer);
            const wavBlob = this.audioBufferToWav(processedBuffer);
            const url = URL.createObjectURL(wavBlob);

            const audio = new Audio(url);
            audio.play();

            audio.onended = () => {
                URL.revokeObjectURL(url);
            };

            return { success: true, message: 'Playing processed audio' };

        } catch (error) {
            console.error('Playback error:', error);
            return { success: false, message: `Playback error: ${error.message}` };
        }
    }

    /**
     * Download processed audio as WAV
     */
    async downloadProcessed() {
        if (!this.audioBlob) return { success: false, message: 'No recording to download' };

        try {
            const arrayBuffer = await this.audioBlob.arrayBuffer();
            const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);
            const processedBuffer = await this.applyEffects(audioBuffer);
            const wavBlob = this.audioBufferToWav(processedBuffer);

            const url = URL.createObjectURL(wavBlob);
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const a = document.createElement('a');
            a.href = url;
            a.download = `ff-pro-voice-${this.currentEffect}-${timestamp}.wav`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);

            setTimeout(() => URL.revokeObjectURL(url), 5000);

            return { success: true, message: 'Download started' };

        } catch (error) {
            console.error('Download error:', error);
            return { success: false, message: `Download error: ${error.message}` };
        }
    }

    /**
     * Apply selected audio effects using Tone.js
     */
    async applyEffects(audioBuffer) {
        const effect = this.currentEffect;
        const sampleRate = audioBuffer.sampleRate;
        const numChannels = audioBuffer.numberOfChannels;
        const length = audioBuffer.length;
        const duration = audioBuffer.duration;

        // Create offline context for processing
        const offlineCtx = new OfflineAudioContext(numChannels, length, sampleRate);

        // Create buffer source
        const source = offlineCtx.createBufferSource();
        source.buffer = audioBuffer;

        // Apply effects based on selection
        let destination = offlineCtx.destination;

        switch (effect) {
            case 'robot': {
                // Robot: heavy pitch shift + distortion
                const pitchShift = new Tone.PitchShift({
                    pitch: this.pitch * 12, // semitones
                    windowSize: 0.1
                }).toDestination();

                const distortion = new Tone.Distortion(0.6).toDestination();
                source.connect(pitchShift);
                source.connect(distortion);
                break;
            }

            case 'alien': {
                // Alien: high pitch + tremolo
                const pitchShift = new Tone.PitchShift({
                    pitch: this.pitch * 18,
                    windowSize: 0.05
                }).toDestination();

                const tremolo = new Tone.Tremolo({
                    frequency: 8,
                    depth: 0.7
                }).toDestination().start();

                source.connect(pitchShift);
                source.connect(tremolo);
                break;
            }

            case 'female': {
                // Female: higher pitch, slight brightness
                const pitchShift = new Tone.PitchShift({
                    pitch: this.pitch * 8,
                    windowSize: 0.15
                }).toDestination();

                const filter = new Tone.Filter({
                    frequency: 3000,
                    type: 'highpass'
                }).toDestination();

                source.connect(pitchShift);
                source.connect(filter);
                break;
            }

            case 'male': {
                // Male Deep: low pitch, slight reverb
                const pitchShift = new Tone.PitchShift({
                    pitch: -this.pitch * 6,
                    windowSize: 0.2
                }).toDestination();

                const reverb = new Tone.Reverb({
                    decay: 1.5,
                    wet: 0.2
                }).toDestination();

                source.connect(pitchShift);
                source.connect(reverb);
                break;
            }

            case 'monster': {
                // Monster: very low + high distortion
                const pitchShift = new Tone.PitchShift({
                    pitch: -this.pitch * 14,
                    windowSize: 0.3
                }).toDestination();

                const distortion = new Tone.Distortion(0.9).toDestination();
                source.connect(pitchShift);
                source.connect(distortion);
                break;
            }

            case 'chipmunk': {
                // Chipmunk: very high pitch
                const pitchShift = new Tone.PitchShift({
                    pitch: this.pitch * 24,
                    windowSize: 0.02
                }).toDestination();
                source.connect(pitchShift);
                break;
            }

            case 'reverb': {
                // Reverb Hall
                const reverb = new Tone.Reverb({
                    decay: Math.max(1, this.reverb / 20),
                    wet: Math.min(0.9, this.reverb / 100)
                }).toDestination();

                const filter = new Tone.Filter({
                    frequency: 4000,
                    type: 'lowpass'
                }).toDestination();

                source.connect(reverb);
                source.connect(filter);
                break;
            }

            default: {
                // Normal: just connect directly
                source.connect(offlineCtx.destination);
                break;
            }
        }

        // If no effect matched above, use normal path
        if (effect === 'none') {
            source.connect(offlineCtx.destination);
        } else {
            // For Tone.js effects wrapped paths, still need offline rendering
            source.connect(offlineCtx.destination);
        }

        source.start(0);

        // Render offline
        if (effect !== 'none') {
            // Use Tone.Offline for proper rendering with Tone.js nodes
            const rendered = await Tone.Offline(() => {
                const bufferSource = new Tone.BufferSource(audioBuffer);
                // Re-apply via Tone
                switch (effect) {
                    case 'robot': {
                        const ps = new Tone.PitchShift(this.pitch * 12);
                        const dist = new Tone.Distortion(0.6);
                        bufferSource.chain(ps, dist, Tone.Destination);
                        break;
                    }
                    case 'alien': {
                        const ps2 = new Tone.PitchShift(this.pitch * 18);
                        const trem = new Tone.Tremolo(8, 0.7).start();
                        bufferSource.chain(ps2, trem, Tone.Destination);
                        break;
                    }
                    case 'female': {
                        const ps3 = new Tone.PitchShift(this.pitch * 8);
                        bufferSource.chain(ps3, Tone.Destination);
                        break;
                    }
                    case 'male': {
                        const ps4 = new Tone.PitchShift(-this.pitch * 6);
                        bufferSource.chain(ps4, Tone.Destination);
                        break;
                    }
                    case 'monster': {
                        const ps5 = new Tone.PitchShift(-this.pitch * 14);
                        const dist2 = new Tone.Distortion(0.9);
                        bufferSource.chain(ps5, dist2, Tone.Destination);
                        break;
                    }
                    case 'chipmunk': {
                        const ps6 = new Tone.PitchShift(this.pitch * 24);
                        bufferSource.chain(ps6, Tone.Destination);
                        break;
                    }
                    case 'reverb': {
                        const rev = new Tone.Reverb(Math.max(1, this.reverb / 20));
                        bufferSource.chain(rev, Tone.Destination);
                        break;
                    }
                    default: {
                        bufferSource.toDestination();
                    }
                }
                bufferSource.start(0);
            }, duration);

            return rendered;
        }

        // For 'none' effect, use basic offline rendering
        const renderedBuffer = await offlineCtx.startRendering();
        return renderedBuffer;
    }

    /**
     * Convert AudioBuffer to WAV Blob
     */
    audioBufferToWav(audioBuffer) {
        const numChannels = audioBuffer.numberOfChannels;
        const sampleRate = audioBuffer.sampleRate;
        const format = 1; // PCM
        const bitDepth = 16;

        // Get channel data
        const channelData = [];
        for (let ch = 0; ch < numChannels; ch++) {
            channelData.push(audioBuffer.getChannelData(ch));
        }

        const samplesLength = channelData[0].length;
        const bufferLength = 44 + samplesLength * numChannels * 2;
        const arrayBuffer = new ArrayBuffer(bufferLength);
        const view = new DataView(arrayBuffer);

        // Write WAV header
        this.writeString(view, 0, 'RIFF');
        view.setUint32(4, bufferLength - 8, true);
        this.writeString(view, 8, 'WAVE');
        this.writeString(view, 12, 'fmt ');
        view.setUint32(16, 16, true); // chunk size
        view.setUint16(20, format, true);
        view.setUint16(22, numChannels, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, sampleRate * numChannels * 2, true);
        view.setUint16(32, numChannels * 2, true);
        view.setUint16(34, bitDepth, true);
        this.writeString(view, 36, 'data');
        view.setUint32(40, samplesLength * numChannels * 2, true);

        // Write samples
        let offset = 44;
        for (let i = 0; i < samplesLength; i++) {
            for (let ch = 0; ch < numChannels; ch++) {
                const sample = Math.max(-1, Math.min(1, channelData[ch][i]));
                const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
                view.setInt16(offset, intSample, true);
                offset += 2;
            }
        }

        return new Blob([arrayBuffer], { type: 'audio/wav' });
    }

    writeString(view, offset, string) {
        for (let i = 0; i < string.length; i++) {
            view.setUint8(offset + i, string.charCodeAt(i));
        }
    }

    /**
     * Audio visualizer using canvas
     */
    startVisualizer() {
        if (!this.canvas || !this.analyserNode || !this.canvasCtx) return;

        const draw = () => {
            this.animationId = requestAnimationFrame(draw);

            const bufferLength = this.analyserNode.frequencyBinCount;
            const dataArray = new Uint8Array(bufferLength);
            this.analyserNode.getByteFrequencyData(dataArray);

            const width = this.canvas.width;
            const height = this.canvas.height;
            const barWidth = width / bufferLength;

            this.canvasCtx.fillStyle = '#0a0a14';
            this.canvasCtx.fillRect(0, 0, width, height);

            // Gradient bars
            const gradient = this.canvasCtx.createLinearGradient(0, 0, 0, height);
            gradient.addColorStop(0, '#ff6b00');
            gradient.addColorStop(0.5, '#e94560');
            gradient.addColorStop(1, '#2979ff');

            for (let i = 0; i < bufferLength; i++) {
                const barHeight = (dataArray[i] / 255) * height;
                const x = i * barWidth;
                const y = height - barHeight;

                this.canvasCtx.fillStyle = gradient;
                this.canvasCtx.fillRect(x, y, barWidth - 1, barHeight);
            }
        };

        draw();
    }

    stopVisualizer() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }
        // Clear canvas
        if (this.canvasCtx && this.canvas) {
            this.canvasCtx.fillStyle = '#0a0a14';
            this.canvasCtx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        }
    }

    /**
     * Bind UI events for voice changer controls
     */
    bindUIEvents() {
        // Effect selector
        const effectSelect = document.getElementById('effectSelect');
        if (effectSelect) {
            effectSelect.addEventListener('change', (e) => {
                this.currentEffect = e.target.value;
                this.updateStatus(`Effect changed to: ${e.target.options[e.target.selectedIndex].text}`);
            });
        }

        // Pitch slider
        const pitchSlider = document.getElementById('pitchSlider');
        const pitchValue = document.getElementById('pitchValue');
        if (pitchSlider) {
            pitchSlider.addEventListener('input', (e) => {
                this.pitch = parseFloat(e.target.value);
                if (pitchValue) pitchValue.textContent = this.pitch.toFixed(1);
            });
        }

        // Speed slider
        const speedSlider = document.getElementById('speedSlider');
        const speedValue = document.getElementById('speedValue');
        if (speedSlider) {
            speedSlider.addEventListener('input', (e) => {
                this.speed = parseFloat(e.target.value);
                if (speedValue) speedValue.textContent = this.speed.toFixed(1);
            });
        }

        // Reverb slider
        const reverbSlider = document.getElementById('reverbSlider');
        const reverbValue = document.getElementById('reverbValue');
        if (reverbSlider) {
            reverbSlider.addEventListener('input', (e) => {
                this.reverb = parseInt(e.target.value);
                if (reverbValue) reverbValue.textContent = `${this.reverb}%`;
            });
        }

        // Record button
        const startBtn = document.getElementById('startRecordBtn');
        const stopBtn = document.getElementById('stopRecordBtn');
        const playBtn = document.getElementById('playBtn');
        const downloadBtn = document.getElementById('downloadBtn');

        if (startBtn) {
            startBtn.addEventListener('click', async () => {
                const result = await this.startRecording();
                if (result.success) {
                    startBtn.disabled = true;
                    stopBtn.disabled = false;
                    this.updateStatus('🔴 Recording... Speak now!');
                } else {
                    this.updateStatus(`⚠️ ${result.message}`);
                }
            });
        }

        if (stopBtn) {
            stopBtn.addEventListener('click', () => {
                const result = this.stopRecording();
                if (result.success) {
                    startBtn.disabled = false;
                    stopBtn.disabled = true;
                    playBtn.disabled = false;
                    downloadBtn.disabled = false;
                    this.updateStatus('✅ Recording complete! You can now play or download.');
                }
            });
        }

        if (playBtn) {
            playBtn.addEventListener('click', async () => {
                playBtn.disabled = true;
                this.updateStatus('⏳ Processing audio...');
                const result = await this.playProcessed();
                playBtn.disabled = false;
                this.updateStatus(result.success ? '▶️ Playing...' : `⚠️ ${result.message}`);
            });
        }

        if (downloadBtn) {
            downloadBtn.addEventListener('click', async () => {
                downloadBtn.disabled = true;
                this.updateStatus('⏳ Processing download...');
                const result = await this.downloadProcessed();
                downloadBtn.disabled = false;
                this.updateStatus(result.success ? '✅ Download started!' : `⚠️ ${result.message}`);
            });
        }
    }

    updateStatus(message) {
        const statusEl = document.getElementById('vcStatus');
        if (statusEl) statusEl.textContent = message;
    }

    /**
     * Clean up resources
     */
    destroy() {
        this.stopRecording();
        this.stopVisualizer();
        if (this.audioUrl) {
            URL.revokeObjectURL(this.audioUrl);
        }
        if (this.audioContext) {
            this.audioContext.close();
            this.audioContext = null;
        }
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.voiceEngine = new VoiceChangerEngine();
});

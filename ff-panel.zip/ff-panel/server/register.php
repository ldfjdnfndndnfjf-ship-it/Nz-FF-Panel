<?php
/**
 * ============================================
 * FF Pro Panel — User Registration API
 * ============================================
 */

require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON input']);
    exit();
}

$username = trim($input['username'] ?? '');
$email    = trim($input['email'] ?? '');
$password = $input['password'] ?? '';
$referral = trim($input['referral'] ?? '');

if (empty($username) || empty($email) || empty($password)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit();
}

if (strlen($password) < 6) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
    exit();
}

if (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Username must be 3-20 alphanumeric characters']);
    exit();
}

try {
    $db = Database::getInstance();

    $existing = $db->fetchOne("SELECT id FROM users WHERE username = ?", [$username]);
    if ($existing) {
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'Username already taken']);
        exit();
    }

    $existing = $db->fetchOne("SELECT id FROM users WHERE email = ?", [$email]);
    if ($existing) {
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'Email already registered']);
        exit();
    }

    $referralCode = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

    $userId = $db->insert(
        "INSERT INTO users (username, email, password, referral_code, referred_by, coins, created_at) VALUES (?, ?, ?, ?, ?, 50, NOW())",
        [$username, $email, $hashedPassword, $referralCode, $referral ?: null]
    );

    $db->execute(
        "INSERT INTO activity_log (user_id, action, details, ip_address, created_at) VALUES (?, 'register', ?, ?, NOW())",
        [$userId, "New user registered: $username", $_SERVER['REMOTE_ADDR'] ?? 'unknown']
    );

    echo json_encode([
        'success' => true,
        'message' => 'Registration successful! Welcome to FF Pro Panel.',
        'user_id' => $userId,
        'referral_code' => $referralCode
    ]);

} catch (Exception $e) {
    error_log("Registration Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error. Please try again.']);
}

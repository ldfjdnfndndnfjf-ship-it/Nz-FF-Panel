<?php
/**
 * ============================================
 * FF Pro Panel — Configuration
 * ============================================
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Database configuration (Will be replaced with live db info on server)
define('DB_HOST', 'localhost');
define('DB_NAME', 'ff_pro_panel');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Site configuration
define('SITE_NAME', 'FF Pro Panel');
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
define('SITE_URL', $protocol . $_SERVER['HTTP_HOST']);
define('API_VERSION', '1.0.0');
define('JWT_SECRET', 'ff-pro-panel-secret-key-2026-custom');

define('SESSION_LIFETIME', 86400); 
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_TIMEOUT', 900); 

// CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

date_default_timezone_set('Asia/Karachi');
